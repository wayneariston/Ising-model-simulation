#!/usr/bin/bash
g++ --std=c++11 -shared -fPIC -o ising_lattice_lib.so ising_lattice_lib.cxx
